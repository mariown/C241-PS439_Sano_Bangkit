const axios = require("axios");

const predictStroke = async (req, res) => {
	const { age, avg_glucose_level, bmi, hypertension, heart_disease, smoking_status } = req.body;
	const { userId } = req.user;
	try {
		const response = await axios.post(`${process.env.FLASK_URL}/predict_stroke`, {
			age, avg_glucose_level, bmi, hypertension, heart_disease, smoking_status
		})

		const stroke_risk = response.data.stroke_risk;

		res.json({ stroke_risk });
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
}

const predictDiabetes = async (req, res) => {
	const { pregnancies, glucose, bloodPressure, skinThickness, insulin, bmi, diabetesPedigreeFunction, age } = req.body;
	const { userId } = req.user;
	try {
		const response = await axios.post(`${process.env.FLASK_URL}/predict_diabetes`, {
			pregnancies, glucose, bloodPressure, skinThickness, insulin, bmi, diabetesPedigreeFunction, age
		})

		const diabetes_risk = response.data.diabetes_risk;

		res.json({ diabetes_risk });
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
}

const predictHeartDisease = async (req, res) => {
	const { age, troponin, kcm, glucose, pressureheight, pressurelow } = req.body;
	const { userId } = req.user;
	try {
		const response = await axios.post(`${process.env.FLASK_URL}/predict_heart_disease`, {
			age, troponin, kcm, glucose, pressureheight, pressurelow
		})

		const heart_disease_risk = response.data.heart_disease_risk;

    res.json({ heart_disease_risk });
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
}

module.exports = {
	predictDiabetes,
	predictHeartDisease,
	predictStroke,
}