/*
  Warnings:

  - Added the required column `idUser` to the `diabetesprediction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `idUser` to the `heartdiseaseprediction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `idUser` to the `strokeprediction` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `diabetesprediction` ADD COLUMN `idUser` INTEGER NOT NULL;

-- AlterTable
ALTER TABLE `heartdiseaseprediction` ADD COLUMN `idUser` INTEGER NOT NULL;

-- AlterTable
ALTER TABLE `strokeprediction` ADD COLUMN `idUser` INTEGER NOT NULL;

-- AddForeignKey
ALTER TABLE `diabetesprediction` ADD CONSTRAINT `diabetesprediction_idUser_fkey` FOREIGN KEY (`idUser`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `heartdiseaseprediction` ADD CONSTRAINT `heartdiseaseprediction_idUser_fkey` FOREIGN KEY (`idUser`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `strokeprediction` ADD CONSTRAINT `strokeprediction_idUser_fkey` FOREIGN KEY (`idUser`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
