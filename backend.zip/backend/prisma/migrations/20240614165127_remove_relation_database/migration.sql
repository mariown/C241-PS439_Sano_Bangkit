/*
  Warnings:

  - You are about to drop the column `idUser` on the `diabetesprediction` table. All the data in the column will be lost.
  - You are about to drop the column `idUser` on the `heartdiseaseprediction` table. All the data in the column will be lost.
  - You are about to drop the column `idUser` on the `strokeprediction` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE `diabetesprediction` DROP FOREIGN KEY `diabetesprediction_idUser_fkey`;

-- DropForeignKey
ALTER TABLE `heartdiseaseprediction` DROP FOREIGN KEY `heartdiseaseprediction_idUser_fkey`;

-- DropForeignKey
ALTER TABLE `strokeprediction` DROP FOREIGN KEY `strokeprediction_idUser_fkey`;

-- AlterTable
ALTER TABLE `diabetesprediction` DROP COLUMN `idUser`;

-- AlterTable
ALTER TABLE `heartdiseaseprediction` DROP COLUMN `idUser`;

-- AlterTable
ALTER TABLE `strokeprediction` DROP COLUMN `idUser`;
